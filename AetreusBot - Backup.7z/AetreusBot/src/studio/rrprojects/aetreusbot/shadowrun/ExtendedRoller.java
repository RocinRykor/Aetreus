package studio.rrprojects.aetreusbot.shadowrun;

import studio.rrprojects.aetreusbot.command.CommandParser.CommandContainer;
import studio.rrprojects.aetreusbot.shadowrun.Shadowrun.RollContainer;

public class ExtendedRoller {

	public static RollContainer Roll(RollContainer rollContainer, CommandContainer cmd) {
		return rollContainer;
	}

}
