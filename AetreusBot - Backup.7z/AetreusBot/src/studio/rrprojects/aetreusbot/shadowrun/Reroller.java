package studio.rrprojects.aetreusbot.shadowrun;

import studio.rrprojects.aetreusbot.shadowrun.Shadowrun.RollContainer;

public class Reroller {

	public static RollContainer Roll(RollContainer rollContainer) {
		
		
		return rollContainer;
	}

}
